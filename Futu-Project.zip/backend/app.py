import os
# 检查并设置工作目录为 app.py 的上一级目录
current_dir = os.getcwd()
target_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if current_dir != target_dir:
    os.chdir(target_dir)


import sys
from flask import Flask
from werkzeug.utils import secure_filename
# 添加项目根路径，便于导入 config 和模块
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from config import config
from PIL import Image
from database_module.schema import create_tables
app = Flask(__name__)

# 注册蓝图
from route.index import index_bp
from route.build_index import build_index_bp
from route.search import search_bp
from route.image import image_bp
from route.repeated_search import bp as repeated_search_bp
from route.get_dataset_id import bp as get_dataset_id_bp

app.register_blueprint(index_bp)
app.register_blueprint(build_index_bp)
app.register_blueprint(search_bp)
app.register_blueprint(image_bp)
app.register_blueprint(repeated_search_bp)
app.register_blueprint(get_dataset_id_bp)

if __name__ == '__main__':
    # 创建必要目录
    os.makedirs('data/indexes', exist_ok=True)
    os.makedirs('data/uploads', exist_ok=True)
    os.makedirs('datasets', exist_ok=True)
    
    # 确保数据库表已创建
    create_tables()
    
    app.run(debug=True, port=19198)
    # 运行 Flask 应用

