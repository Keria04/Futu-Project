import './assets/main.css'

import { createApp } from 'vue'
import App from './App.vue'

// 建议：无须更改，如需代理请见 vite.config.js
createApp(App).mount('#app')
